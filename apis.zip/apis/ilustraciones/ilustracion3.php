<?php

$json = '{"numeros":[1,2,3,4,5]}';

function operacionEnCadaElemento ($data, $callback){
    $data = json_decode($data);
    foreach ($data->numeros as $numero){
        $resultado = $callback($numero);
        echo $resultado. PHP_EOL;
    }
}

function cuadrado($x){
    return $x * $x;
}

operacionEnCadaElemento($json,'cuadrado');