<?php
class TaskModel
{
    private $tasks = [];

    public function __construct()
    {
        //Inicializar con algunas tareas de ejemplo
        $this->tasks[] = ['id' => 1, 'title' => 'Hacer la compra'];
        $this->tasks[] = ['id' => 2, 'title' => 'Hacer Ejercicio'];
        $this->tasks[] = ['id' => 3, 'title' => 'hacer la comida'];         
    }

    public function getAllTasks()
    {
        return $this->tasks;
    }

    public function getTaskById($id)
    {
        foreach ($this->tasks as $task)
        {
            if ($task['id'] == $id){
                return $task;
            }
        }
    return null;
    }

    //otros metodos como agregar, actualizar y eliminar tareas
}