<?php
require_once 'models/TaskModel.php';
require_once 'controllers/TaskController.php';

// Crear instancia del modelo
$model = new TaskModel();

// Crear instancia del controlador
$controller = new TaskController($model);

// Enrutamiento
if (isset($_GET['action'])){
    $action = $_GET['action'];
    switch ($action) {
        case 'getAllTasks':
            echo $controller->getAllTasks();
            break;
        case 'getTaskById':
            if(isset($_GET['id'])) {
                echo $controller->getTaskById($_GET['id']);
            } else {
                echo json_encode(['message' => 'se requiere un ID']);
            }
            break;
            // otros casos para agregar, actualizar y eliminar tareas
        default:
            echo json_encode(['message' => 'Accion no Valida']);
    }
}